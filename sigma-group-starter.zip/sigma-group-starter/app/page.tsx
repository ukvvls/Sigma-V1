import {
  ArrowLeft, ArrowUpLeft, Beaker, Boxes, Building2, CheckCircle2,
  ChevronLeft, ClipboardList, FileText, FlaskConical, Headset,
  LayoutDashboard, Package, Search, ShieldCheck, ShoppingCart,
  Truck, Wallet, Menu, Bell, Clock3
} from "lucide-react";

const products = [
  { code: "RM-1024", name: "مادة خام دوائية – عينة تجريبية", category: "خامات دوائية", unit: "عبوة / حسب المواصفة", status: "متاح للاستعلام", tone: "blue" },
  { code: "FP-2041", name: "منتج نهائي – عينة تجريبية", category: "منتجات نهائية", unit: "كرتونة", status: "متاح للاستعلام", tone: "mint" },
  { code: "EX-3012", name: "مادة مساعدة – عينة تجريبية", category: "مواد مساعدة", unit: "كيلوجرام", status: "طلب عرض سعر", tone: "sand" },
];

const activities = [
  { id: "#SG-1048", title: "طلب شراء تجريبي", date: "17 نوفمبر 2026", state: "قيد المراجعة", cls: "pending", amount: "—" },
  { id: "#SG-1039", title: "فاتورة تجريبية", date: "12 نوفمبر 2026", state: "بانتظار السداد", cls: "due", amount: "—" },
  { id: "#SG-1027", title: "طلب سابق تجريبي", date: "08 نوفمبر 2026", state: "تم التسليم", cls: "done", amount: "—" },
];

function Brand() {
  return <div className="brand"><div className="brand-mark">Σ</div><div><b>SIGMA GROUP</b><span>PHARMACEUTICALS</span></div></div>;
}
function Sidebar() {
  const links = [
    [LayoutDashboard, "الرئيسية", true], [ShoppingCart, "السوق والمنتجات"], [ClipboardList, "طلباتي"],
    [FileText, "الفواتير"], [Wallet, "حسابي المالي"], [Boxes, "المخزون والتوفر"], [Headset, "الدعم والمساعدة"]
  ] as const;
  return <aside className="sidebar"><Brand/><div className="side-label">مساحة العميل</div><nav>{links.map(([Icon, label, active]) => <a className={active ? "nav-link active" : "nav-link"} href="#" key={label}><Icon size={18}/><span>{label}</span>{active && <i/>}</a>)}</nav><div className="side-help"><div className="help-icon"><Headset size={19}/></div><b>هل تحتاج إلى مساعدة؟</b><p>فريق خدمة العملاء جاهز لمساعدتك.</p><button>تواصل معنا <ArrowLeft size={14}/></button></div><div className="side-foot">© 2026 SIGMA GROUP</div></aside>;
}
function Header() {
  return <header className="topbar"><div className="crumb"><span>مساحة العميل</span><ChevronLeft size={14}/><b>الرئيسية</b></div><div className="top-actions"><button className="icon-btn" aria-label="القائمة"><Menu size={18}/></button><button className="icon-btn notify" aria-label="الإشعارات"><Bell size={18}/><i/></button><div className="user"><div className="avatar">ع</div><div><b>حساب تجريبي</b><span>شركة العميل</span></div><ChevronLeft size={15}/></div></div></header>;
}
function Metric({ icon: Icon, label, value, hint, color }: { icon: React.ElementType; label: string; value: string; hint: string; color: string }) {
  return <div className="metric"><div className={`metric-icon ${color}`}><Icon size={20}/></div><div className="metric-copy"><span>{label}</span><strong>{value}</strong><small>{hint}</small></div></div>;
}
export default function Home() {
  return <div className="app-shell"><Sidebar/><main className="main"><Header/><div className="content">
    <section className="welcome"><div><div className="eyebrow"><span/> بوابة الأعمال للشركات</div><h1>مرحباً بك في <em>SIGMA GROUP</em></h1><p>منصة موحدة لإدارة مشترياتك ومتابعة طلباتك وحساباتك التجارية بكل سهولة.</p><div className="welcome-actions"><button className="primary"><ShoppingCart size={17}/> تصفح المنتجات <ArrowLeft size={16}/></button><button className="secondary">عرض طلباتي</button></div></div><div className="welcome-art"><div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/><div className="art-symbol">Σ</div><div className="art-tag"><ShieldCheck size={15}/> شراكة موثوقة</div></div></section>
    <div className="section-head"><div><h2>نظرة عامة على الحساب</h2><p>ملخص سريع لحركة حساب شركتك.</p></div><span className="date-chip"><Clock3 size={14}/> آخر تحديث: اليوم</span></div>
    <section className="metrics"><Metric icon={Wallet} label="الرصيد المستحق" value="— ج.م" hint="يظهر بعد تفعيل الحساب المالي" color="violet"/><Metric icon={ShieldCheck} label="الحد الائتماني" value="غير محدد" hint="يحدده فريق الحسابات" color="green"/><Metric icon={ClipboardList} label="الطلبات النشطة" value="01" hint="طلب تجريبي قيد المراجعة" color="blue"/><Metric icon={FileText} label="الفواتير المستحقة" value="—" hint="لا توجد بيانات مالية فعلية" color="orange"/></section>
    <section className="quick-grid"><a className="quick-card" href="#"><div className="quick-icon q-blue"><FlaskConical size={21}/></div><div><b>الخامات الدوائية</b><span>تصفح المواد الخام والمواصفات</span></div><ArrowUpLeft size={17}/></a><a className="quick-card" href="#"><div className="quick-icon q-green"><Package size={21}/></div><div><b>المنتجات النهائية</b><span>اكتشف المنتجات المتاحة</span></div><ArrowUpLeft size={17}/></a><a className="quick-card" href="#"><div className="quick-icon q-gold"><FileText size={21}/></div><div><b>الفواتير وكشف الحساب</b><span>راجع مستنداتك المالية</span></div><ArrowUpLeft size={17}/></a></section>
    <section className="lower-grid"><div className="panel"><div className="panel-head"><div><h2>آخر الطلبات والعمليات</h2><p>تابع أحدث نشاط على حسابك.</p></div><a href="#">عرض الكل <ArrowLeft size={14}/></a></div><div className="table-wrap"><table><thead><tr><th>رقم العملية</th><th>التفاصيل</th><th>التاريخ</th><th>الحالة</th><th>القيمة</th></tr></thead><tbody>{activities.map(a=><tr key={a.id}><td className="code">{a.id}</td><td>{a.title}</td><td>{a.date}</td><td><span className={`status ${a.cls}`}>{a.state}</span></td><td>{a.amount}</td></tr>)}</tbody></table></div><div className="demo-note"><CheckCircle2 size={15}/> هذه بيانات توضيحية للعرض فقط، وليست سجلات شراء أو حسابات حقيقية.</div></div>
    <div className="panel products-panel"><div className="panel-head"><div><h2>منتجات مقترحة</h2><p>نماذج توضيحية للكتالوج.</p></div><a href="#">السوق <ArrowLeft size={14}/></a></div>{products.map((p,i)=><div className="product-row" key={p.code}><div className={`product-icon ${p.tone}`}>{i===0?<Beaker size={20}/>:i===1?<Package size={20}/>:<FlaskConical size={20}/>}</div><div className="product-info"><b>{p.name}</b><span>{p.code} · {p.category}</span><small>{p.unit}</small></div><span className="availability">{p.status}</span></div>)}</div></section>
    <footer><span>© 2026 SIGMA GROUP. جميع الحقوق محفوظة.</span><span>منصة الأعمال والمشتريات</span></footer>
  </div></main></div>;
}
