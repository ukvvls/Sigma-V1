import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sigma Group | منصة الأعمال الدوائية",
  description: "منصة سيجما جروب للمشتريات والمنتجات والخامات الدوائية في مصر.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
